import httpx

from telethon import events
from ubb import Ubot


@Ubot.on(events.NewMessage(pattern=r'\.pk'))
async def pae(event):
    key = event.message.message[len('.pk '):]
    reply_msg = await event.get_reply_message()
    if reply_msg:
        key = reply_msg.message

    async with httpx.AsyncClient(http2=True) as client:
        head = {
            "Host": "gateway.paylike.io",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload = {
            "key": key,
            "number": int(4919190013022323),
            "expiry[month]": int(11),
            "expiry[year]": int(2024),
            "code": int(110)
        }
        r = await client.post('https://gateway.paylike.io/cards', headers=head, json=payload)
        if "26" in r.text:
          await event.edit('**Paylike Key Checker**\n'
                           f'**KEY**⟿ `{key}`\n'
                           '**STATUS**⟿ ❌INVALID**\n'
                           '**USERBOTBY**⟿ @Xbinner')
        elif "28" in r.text:
          await event.edit('**Paylike Key Checker**\n'
                           f'**KEY**⟿ `{key}`\n'
                           '**STATUS**⟿ ✅VALID[3DS]**\n'
                           '**USERBOTBY**⟿ @Xbinner')
        else:
          await event.edit('**Paylike Key Checker**\n'
                           f'**KEY**⟿ `{key}`\n'
                           '**STATUS**⟿ ✅VALID**\n'
                           f'**{r.text}\n'
                           '**USERBOTBY**⟿ @Xbinner')
        print(r.text)
