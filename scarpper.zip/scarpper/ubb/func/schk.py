from ubb import SUDO_USERS


async def is_sudo(user_id: int):
    status = False
    if user_id in SUDO_USERS:
            status = True
            # break
    return status
