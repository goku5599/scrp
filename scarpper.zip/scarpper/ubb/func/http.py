import httpx


async def get(url: str):
    headers = {
        "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.0.0 Mobile Safari/537.36",
        "accept": "application/json, text/plain, */*",
        "content-type": "application/x-www-form-urlencoded"
        }
    async with httpx.AsyncClient(headers=headers) as client:
             r = await client.get(url, follow_redirects=True)
    return r


async def post(url: str, pdata):
    async with httpx.AsyncClient() as client:
             r = await client.post(url,
                                   data=pdata
                                   )
    return r
